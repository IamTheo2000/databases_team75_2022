insert into Xoroi (id_xorou, plithos_klinon, onomasia_xorou, perigrafi_thesi_xorou, id_ipiresias) values (655, 0, 'Kommotirio', 1, 4);
