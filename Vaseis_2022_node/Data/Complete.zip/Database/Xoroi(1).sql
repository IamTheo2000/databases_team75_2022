insert into Xoroi (id_xorou, plithos_klinon, onomasia_xorou, perigrafi_thesi_xorou, id_ipiresias) values (414, 0, 'Estiatorio', 1, 3);
insert into Xoroi (id_xorou, plithos_klinon, onomasia_xorou, perigrafi_thesi_xorou, id_ipiresias) values (466, 0, 'Estiatorio', 2, 3);
insert into Xoroi (id_xorou, plithos_klinon, onomasia_xorou, perigrafi_thesi_xorou, id_ipiresias) values (410, 0, 'Estiatorio', 3, 3);
insert into Xoroi (id_xorou, plithos_klinon, onomasia_xorou, perigrafi_thesi_xorou, id_ipiresias) values (489, 0, 'Estiatorio', 4, 3);
